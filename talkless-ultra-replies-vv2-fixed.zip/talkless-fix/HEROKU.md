# Deploying Talkless Ultra on Heroku

This project runs as a **worker**, not an HTTP website. `Procfile` starts the worker with `npm start`, and `app.json` describes a single Basic worker for manifest-based deployment.

## Deploy

1. Push the project to a private GitHub repository (do not commit `.env`, WhatsApp session files, or tokens).
2. Create a Heroku app and connect the repository, or deploy it using Heroku's supported Git workflow.
3. In the app's **Settings → Config Vars**, set at least `TELEGRAM_TOKEN`. Set `OWNER_TELEGRAM_ID` if Telegram owner/pairing features are needed. Add any integration variables required by your setup, such as `NEON_DATABASE_URL` or the `GITHUB_*` variables.
4. Enable one `worker` dyno. No web dyno or web port is required.
5. Review the worker logs, pair a WhatsApp number, then restart the worker once and verify the session reconnects.

Never place real credentials in `app.json`, source files, or a public repository. Set them as Heroku Config Vars.

## WhatsApp session persistence warning

Heroku dyno filesystems are not durable across dyno replacement/restarts. WhatsApp credentials and the sent-message retry cache are written locally by this project. Configure and test the project's GitHub session backup/restore integration (`GITHUB_TOKEN`, `GITHUB_USERNAME`, `GITHUB_REPO`, and `GITHUB_BRANCH`) before relying on a Heroku worker restart. A dyno restart without a working external session backup may require pairing the WhatsApp number again. The `sent-cache.json` retry cache is also local; it may be lost on a dyno replacement, so this change cannot guarantee recovery of every old encrypted message after a restart.

## “Waiting for this message”

The bot caches recent outgoing messages to answer WhatsApp retry requests. The cache lookup is scoped by session so a paired number cannot retrieve another session's cached command reply. Test a few command replies from a second device after deployment; if WhatsApp still shows the waiting placeholder, check whether the worker restarted and whether the session/cache backup is working.
