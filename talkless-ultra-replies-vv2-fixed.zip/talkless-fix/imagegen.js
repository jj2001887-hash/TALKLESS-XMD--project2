// imagegen.js – AI image creation commands (text -> image)
'use strict';
const axios = require('axios');

// Keyless provider (Pollinations). Override with IMAGE_API_BASE in .env if you
// host/proxy your own compatible endpoint.
const BASE = (process.env.IMAGE_API_BASE || 'https://image.pollinations.ai/prompt').replace(/\/$/, '');

// Style presets are added to the prompt, so they work with every model.
const PRESETS = {
  imagine:   { label: 'AI Image',  model: 'flux',  style: '' },
  flux:      { label: 'Flux',      model: 'flux',  style: '' },
  dalle:     { label: 'AI Image',  model: 'flux',  style: 'highly detailed, sharp focus, professional quality' },
  aiimage:   { label: 'AI Image',  model: 'flux',  style: '' },
  genimg:    { label: 'AI Image',  model: 'flux',  style: '' },
  turbo:     { label: 'Turbo',     model: 'turbo', style: '' },
  sdxl:      { label: 'Fast',      model: 'turbo', style: 'highly detailed' },
  realistic: { label: 'Realistic', model: 'flux',  style: 'photorealistic, ultra realistic, 8k, DSLR photo, natural lighting, sharp details' },
  animeart:  { label: 'Anime',     model: 'flux',  style: 'anime style, vibrant colors, clean line art, studio quality illustration' },
  cartoonart:{ label: 'Cartoon',   model: 'flux',  style: 'cartoon style, bold outlines, colorful, playful, 2d illustration' },
  '3d':      { label: '3D Render', model: 'flux',  style: '3d render, octane render, ultra detailed, soft studio lighting, pixar style' },
  cyberpunk: { label: 'Cyberpunk', model: 'flux',  style: 'cyberpunk, neon lights, futuristic city, rain, cinematic, highly detailed' },
  fantasy:   { label: 'Fantasy',   model: 'flux',  style: 'epic fantasy art, magical atmosphere, dramatic lighting, intricate details, digital painting' },
  pixelart:  { label: 'Pixel Art', model: 'flux',  style: 'pixel art, 16-bit, retro game style, crisp pixels' },
  sketchart: { label: 'Sketch',    model: 'flux',  style: 'pencil sketch, hand drawn, graphite, detailed shading, on paper' },
  logo:      { label: 'Logo',      model: 'flux',  style: 'minimal vector logo, flat design, clean shapes, centered, white background, professional branding', size: [1024, 1024] },
  wallpaper: { label: 'Wallpaper', model: 'flux',  style: 'ultra wide wallpaper, cinematic, stunning detail, 4k', size: [1344, 768] },
  portrait:  { label: 'Portrait',  model: 'flux',  style: 'portrait, detailed face, soft lighting, high quality', size: [768, 1344] },
};

const IMAGE_CMDS = Object.keys(PRESETS);

function looksLikeImage(buf) {
  if (!buf || buf.length < 5000) return false;
  return (buf[0] === 0xff && buf[1] === 0xd8) ||                                  // jpeg
    (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) || // png
    (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP');
}

async function fetchImage(prompt, model, width, height) {
  const params = new URLSearchParams({
    width: String(width), height: String(height), model,
    seed: String(Math.floor(Math.random() * 1e9)),
    nologo: 'true', enhance: 'false', safe: 'true',
  });
  const url = `${BASE}/${encodeURIComponent(prompt)}?${params}`;
  const res = await axios.get(url, {
    responseType: 'arraybuffer', timeout: 90000, maxContentLength: 25 * 1024 * 1024,
    headers: { 'User-Agent': 'Mozilla/5.0' }, validateStatus: s => s === 200,
  });
  const buf = Buffer.from(res.data);
  if (!looksLikeImage(buf)) throw new Error('provider did not return an image');
  return buf;
}

// Tries the preferred model, retries once, then falls back to the other model.
async function generate(prompt, preferred, width, height) {
  const order = [preferred, preferred, preferred === 'flux' ? 'turbo' : 'flux'];
  let lastErr;
  for (let i = 0; i < order.length; i++) {
    try { return { buffer: await fetchImage(prompt, order[i], width, height), model: order[i] }; }
    catch (e) {
      lastErr = e;
      if (i < order.length - 1) await new Promise(r => setTimeout(r, 1500));
    }
  }
  throw lastErr;
}

async function imageGenHandler(sock, m, cmd, args, helpers) {
  if (!IMAGE_CMDS.includes(cmd)) return false;
  const { reply, ft, cfg, reaction, getQuoted } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const preset = PRESETS[cmd];

  // Options: --wide / --tall / --square and --text "EXACT WORDS"
  let [width, height] = preset.size || [1024, 1024];
  let rawArgs = args.join(' ').trim();
  let requestedText = '';
  const textOption = rawArgs.match(/(?:^|\s)--(?:text|name)(?:=|\s+)(?:"([^"]*)"|'([^']*)'|([^\s]+))/i);
  if (textOption) {
    requestedText = String(textOption[1] ?? textOption[2] ?? textOption[3] ?? '').trim().replace(/[\r\n\t]+/g, ' ').slice(0, 80);
    rawArgs = rawArgs.replace(textOption[0], ' ').replace(/\s+/g, ' ').trim();
  }
  const words = [];
  for (const a of rawArgs.split(/\s+/).filter(Boolean)) {
    const f = a.toLowerCase();
    if (f === '--wide')        [width, height] = [1344, 768];
    else if (f === '--tall')   [width, height] = [768, 1344];
    else if (f === '--square') [width, height] = [1024, 1024];
    else words.push(a);
  }
  let prompt = words.join(' ').trim();

  // allow replying to a text message to use it as the prompt
  if (!prompt) {
    try {
      const { qMsg } = getQuoted(m);
      prompt = (qMsg?.conversation || qMsg?.extendedTextMessage?.text || '').trim();
    } catch {}
  }
  if (!prompt) {
    await reply(
      `🎨 *${prefix}${cmd} <describe the image>*\n\n` +
      `Example: ${prefix}${cmd} a lion wearing a golden crown, sunset\n` +
      `Exact text: ${prefix}${cmd} a sunset city --text "ALEX SMITH"\n` +
      `Size flags: --wide  --tall  --square\n\n` +
      `Styles: ${prefix}realistic ${prefix}animeart ${prefix}cartoonart ${prefix}3d ${prefix}cyberpunk ${prefix}fantasy ` +
      `${prefix}pixelart ${prefix}sketchart ${prefix}logo ${prefix}wallpaper ${prefix}portrait ${prefix}turbo`
    );
    return true;
  }
  prompt = prompt.slice(0, 500);

  reaction('🎨'); // do not make the user wait for the reaction
  try {
    const textInstruction = requestedText
      ? `. Include this exact visible text: "${requestedText}". Spell it exactly as provided, preserve capitalization, make it large and clearly legible, and do not add any other text.`
      : '';
    const imagePrompt = `${prompt}${textInstruction}`;
    const full = preset.style ? `${imagePrompt}, ${preset.style}` : imagePrompt;
    const { buffer, model } = await generate(full, preset.model, width, height);
    await sock.sendMessage(jid, {
      image: buffer,
      caption: ft(`🎨 *${preset.label}*\n📝 ${prompt}${requestedText ? `\n🔤 Text requested: ${requestedText}` : ''}\n⚙️ ${model} · ${width}×${height}`, sock),
    }, { quoted: m });
    reaction('✅');
  } catch (e) {
    reaction('❌');
    await reply(`❌ Could not create the image right now (${e.message}). Please try again in a moment.`);
  }
  return true;
}

module.exports = { imageGenHandler, IMAGE_CMDS };
