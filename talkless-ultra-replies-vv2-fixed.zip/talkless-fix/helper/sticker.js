'use strict';
// ============================================================
//   helper/sticker.js — sticker engine
//   • images  -> sharp (no ffmpeg needed)
//   • videos / gifs / animated webp -> ffmpeg (ffmpeg-static if
//     installed, otherwise the system ffmpeg)
//   • pack name + author are written into the WebP EXIF chunk,
//     which is the only way WhatsApp shows them on a sticker.
// ============================================================
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

let sharp = null;
try { sharp = require('sharp'); } catch { /* reported when used */ }

let FFMPEG = 'ffmpeg';
try { FFMPEG = require('ffmpeg-static') || 'ffmpeg'; } catch { /* use system ffmpeg */ }

const MAX_ANIMATED_BYTES = 950 * 1024; // WhatsApp rejects animated stickers > ~1 MB

function tmpFile(ext) {
  return path.join(os.tmpdir(), `tkx_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`);
}
function rm(...files) { for (const f of files) { try { fs.unlinkSync(f); } catch {} } }

function runFfmpeg(args, timeout = 60000) {
  return new Promise((resolve, reject) => {
    execFile(FFMPEG, args, { timeout, maxBuffer: 1024 * 1024 * 8 }, (err, _out, stderr) => {
      if (err) {
        if (err.code === 'ENOENT') return reject(new Error('ffmpeg is not installed on this server. Run: npm i ffmpeg-static'));
        return reject(new Error(String(stderr || err.message).split('\n').filter(Boolean).slice(-2).join(' ')));
      }
      resolve();
    });
  });
}

// ── WebP EXIF (WhatsApp sticker-pack metadata) ────────────────
function buildExif(pack, author) {
  const json = {
    'sticker-pack-id': crypto.randomBytes(16).toString('hex'),
    'sticker-pack-name': String(pack || ''),
    'sticker-pack-publisher': String(author || ''),
    emojis: [],
  };
  const header = Buffer.from([
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
    0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
  ]);
  const body = Buffer.from(JSON.stringify(json), 'utf8');
  const exif = Buffer.concat([header, body]);
  exif.writeUIntLE(body.length, 14, 4);
  return exif;
}

function readChunks(webp) {
  const chunks = [];
  let off = 12;
  while (off + 8 <= webp.length) {
    const fourcc = webp.toString('ascii', off, off + 4);
    const size = webp.readUInt32LE(off + 4);
    chunks.push({ fourcc, data: webp.subarray(off + 8, off + 8 + size) });
    off += 8 + size + (size & 1);
  }
  return chunks;
}

function imageDims(chunk) {
  const d = chunk.data;
  if (chunk.fourcc === 'VP8L') {
    const bits = d.readUInt32LE(1);
    return { w: (bits & 0x3fff) + 1, h: ((bits >> 14) & 0x3fff) + 1, alpha: !!((bits >> 28) & 1) };
  }
  return { w: d.readUInt16LE(6) & 0x3fff, h: d.readUInt16LE(8) & 0x3fff, alpha: false };
}

function addExif(webp, pack, author) {
  try {
    if (webp.toString('ascii', 0, 4) !== 'RIFF' || webp.toString('ascii', 8, 12) !== 'WEBP') return webp;
    let chunks = readChunks(webp).filter(c => c.fourcc !== 'EXIF');
    let vp8x = chunks.find(c => c.fourcc === 'VP8X');
    if (!vp8x) {
      const img = chunks.find(c => c.fourcc === 'VP8 ' || c.fourcc === 'VP8L');
      if (!img) return webp;
      const { w, h, alpha } = imageDims(img);
      const data = Buffer.alloc(10);
      data[0] = alpha || chunks.some(c => c.fourcc === 'ALPH') ? 0x10 : 0;
      data.writeUIntLE(w - 1, 4, 3);
      data.writeUIntLE(h - 1, 7, 3);
      vp8x = { fourcc: 'VP8X', data };
      chunks.unshift(vp8x);
    }
    vp8x.data = Buffer.from(vp8x.data);
    vp8x.data[0] |= 0x08; // EXIF present
    chunks.push({ fourcc: 'EXIF', data: buildExif(pack, author) });

    const parts = [];
    for (const c of chunks) {
      const head = Buffer.alloc(8);
      head.write(c.fourcc, 0, 'ascii');
      head.writeUInt32LE(c.data.length, 4);
      parts.push(head, c.data);
      if (c.data.length & 1) parts.push(Buffer.alloc(1));
    }
    const body = Buffer.concat(parts);
    const riff = Buffer.alloc(12);
    riff.write('RIFF', 0, 'ascii');
    riff.writeUInt32LE(body.length + 4, 4);
    riff.write('WEBP', 8, 'ascii');
    return Buffer.concat([riff, body]);
  } catch {
    return webp; // never block sending because of metadata
  }
}

// ── Detection ─────────────────────────────────────────────────
function isWebp(buf) { return buf.length > 12 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP'; }
function webpIsAnimated(buf) { return isWebp(buf) && buf.includes(Buffer.from('ANIM')); }

// ffmpeg cannot decode animated WebP, so go through sharp -> GIF first.
async function animatedWebpToGif(buf) {
  if (!sharp) throw new Error('sharp is not installed. Run: npm i sharp');
  return sharp(buf, { animated: true }).gif().toBuffer();
}

// ── Image -> sticker ──────────────────────────────────────────
async function imageToWebp(buf, { crop = false } = {}) {
  if (!sharp) throw new Error('sharp is not installed. Run: npm i sharp');
  return sharp(buf, { animated: webpIsAnimated(buf) })
    .rotate()
    .resize(512, 512, { fit: crop ? 'cover' : 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 75, effort: 4 })
    .toBuffer();
}

// ── Video / gif / animated -> sticker ─────────────────────────
async function videoToWebp(buf, { crop = false, maxSeconds = 8 } = {}) {
  const input = tmpFile('in');
  const output = tmpFile('webp');
  fs.writeFileSync(input, buf);
  try {
    const fit = crop
      ? 'scale=512:512:force_original_aspect_ratio=increase,crop=512:512'
      : 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000';
    const attempts = [
      { fps: 15, q: 45 },
      { fps: 12, q: 35 },
      { fps: 10, q: 25 },
      { fps: 8, q: 15 },
    ];
    let result = null;
    for (const { fps, q } of attempts) {
      await runFfmpeg([
        '-y', '-t', String(maxSeconds), '-i', input,
        '-vf', `fps=${fps},${fit},format=rgba`,
        '-an', '-loop', '0', '-vsync', '0',
        '-c:v', 'libwebp', '-lossless', '0', '-q:v', String(q),
        '-compression_level', '6', '-preset', 'default',
        output,
      ]);
      result = fs.readFileSync(output);
      if (result.length <= MAX_ANIMATED_BYTES) break;
    }
    return result;
  } finally { rm(input, output); }
}

/**
 * Turn any image/video/gif/webp buffer into a ready-to-send WhatsApp sticker.
 * @param {Buffer} buf
 * @param {{isVideo?:boolean, crop?:boolean, pack?:string, author?:string}} opts
 */
async function makeSticker(buf, { isVideo = false, crop = false, pack = '', author = '' } = {}) {
  let webp;
  if (isVideo) webp = await videoToWebp(buf, { crop });
  else if (webpIsAnimated(buf)) webp = await videoToWebp(await animatedWebpToGif(buf), { crop });
  else webp = await imageToWebp(buf, { crop });
  return addExif(webp, pack, author);
}

// ── Sticker -> image / video ──────────────────────────────────
async function stickerToMedia(buf) {
  if (webpIsAnimated(buf)) {
    const input = tmpFile('gif');
    const output = tmpFile('mp4');
    fs.writeFileSync(input, await animatedWebpToGif(buf));
    try {
      await runFfmpeg([
        '-y', '-i', input,
        '-movflags', 'faststart', '-pix_fmt', 'yuv420p',
        '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2:flags=lanczos,format=yuv420p',
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '26', '-an',
        output,
      ]);
      return { type: 'video', buffer: fs.readFileSync(output) };
    } finally { rm(input, output); }
  }
  if (!sharp) throw new Error('sharp is not installed. Run: npm i sharp');
  // flatten onto white so transparent stickers do not turn black in the preview
  const png = await sharp(buf).png().toBuffer();
  return { type: 'image', buffer: png };
}

// ── Text / colour / emoji stickers (no network, no ffmpeg) ────
function escapeXml(s) { return String(s).replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c])); }

async function textToWebp(text, { color } = {}) {
  if (!sharp) throw new Error('sharp is not installed. Run: npm i sharp');
  const clean = String(text).replace(/\s+/g, ' ').trim().slice(0, 120);
  // naive word wrap into lines of ~14 chars
  const words = clean.split(' ');
  const lines = [];
  let cur = '';
  for (const w of words) {
    if ((cur + ' ' + w).trim().length > 14 && cur) { lines.push(cur); cur = w; } else cur = (cur + ' ' + w).trim();
  }
  if (cur) lines.push(cur);
  const shown = lines.slice(0, 6);
  const size = Math.max(40, Math.min(120, Math.floor(480 / Math.max(shown.length, 1) * 0.8)));
  const lineH = size * 1.15;
  const startY = 256 - ((shown.length - 1) * lineH) / 2 + size * 0.35;
  const fill = color || '#ffffff';
  const tspans = shown.map((l, i) =>
    `<text x="256" y="${(startY + i * lineH).toFixed(1)}" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-weight="bold" font-size="${size}" fill="${fill}" stroke="#000" stroke-width="${Math.max(3, size / 12)}" paint-order="stroke">${escapeXml(l)}</text>`).join('');
  const svg = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">${tspans}</svg>`);
  return sharp(svg).webp({ quality: 90 }).toBuffer();
}

async function colorToWebp(color) {
  if (!sharp) throw new Error('sharp is not installed. Run: npm i sharp');
  return sharp({ create: { width: 512, height: 512, channels: 4, background: color } }).webp({ quality: 90 }).toBuffer();
}

// ── Info ──────────────────────────────────────────────────────
function readPackInfo(buf) {
  try {
    const chunk = readChunks(buf).find(c => c.fourcc === 'EXIF');
    if (!chunk) return null;
    const text = chunk.data.toString('utf8');
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start < 0 || end < 0) return null;
    return JSON.parse(text.slice(start, end + 1));
  } catch { return null; }
}

module.exports = {
  makeSticker, addExif, stickerToMedia, textToWebp, colorToWebp,
  readPackInfo, isWebp, webpIsAnimated, imageToWebp, videoToWebp,
};
