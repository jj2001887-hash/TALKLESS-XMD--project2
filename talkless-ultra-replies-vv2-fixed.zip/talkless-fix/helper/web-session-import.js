// ============================================================
//   helper/web-session-import.js
//   Claims session strings pasted on the website (/session) and
//   connects them, so a user can bring an existing session instead
//   of generating a pairing code.
//
//   Flow (all against the same Neon DB the website writes to):
//     pending → claimed → connected | failed
//   The credential is wiped from the database the moment the socket
//   is handed to Baileys, or as soon as the attempt fails.
// ============================================================
'use strict';

try { require('dns').setDefaultResultOrder('ipv4first'); } catch (_) { /* older node */ }

const fs   = require('fs');
const path = require('path');
const { Pool } = require('pg');

let settings = {};
try { settings = require('../settings'); } catch (_) { settings = {}; }

const PREFIX = 'talkless_';
const NEON_URL = String(process.env.NEON_DATABASE_URL || settings.NEON_DATABASE_URL || '').split('?')[0];

const POLL_MS = 8000;
const SESSIONS_DIR = path.resolve(__dirname, '../sessions');

let pool = null;
let started = false;
let busy = false;

function getPool() {
  if (!pool) {
    pool = new Pool({
      connectionString: NEON_URL || undefined,
      ...(NEON_URL ? { ssl: { rejectUnauthorized: false } } : {}),
      connectionTimeoutMillis: 10000,
      idleTimeoutMillis: 30000,
      max: 2,
    });
    pool.on('error', (e) => console.error('[WEB-IMPORT] idle client:', e && e.message));
  }
  return pool;
}

async function ensureTable() {
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS ${PREFIX}session_imports (
      id BIGSERIAL PRIMARY KEY,
      phone TEXT NOT NULL,
      payload TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      claim_token TEXT NOT NULL,
      error TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '10 minutes')
    )`);
  // Older builds created the column as NOT NULL while the wipe/expire queries
  // below intentionally write payload = NULL, which made every cleanup tick
  // fail. Relax the constraint on tables that already exist.
  try {
    await getPool().query(
      `ALTER TABLE ${PREFIX}session_imports ALTER COLUMN payload DROP NOT NULL`);
  } catch (_) {
    // Already nullable, or a role without ALTER rights: nothing to do.
  }
}

// Atomically take the oldest live pending row. SKIP LOCKED means two bot
// instances can poll the same table without ever claiming the same import.
async function claimOne() {
  const { rows } = await getPool().query(`
    UPDATE ${PREFIX}session_imports SET status = 'claimed', updated_at = now()
     WHERE id = (
       SELECT id FROM ${PREFIX}session_imports
        WHERE status = 'pending' AND expires_at > now()
        ORDER BY id
        LIMIT 1
        FOR UPDATE SKIP LOCKED
     )
     RETURNING id, phone, payload`);
  return rows[0] || null;
}

async function markConnected(id) {
  await getPool().query(
    `UPDATE ${PREFIX}session_imports
        SET status = 'connected', payload = NULL, updated_at = now()
      WHERE id = $1`, [id]);
}

async function markFailed(id, message) {
  await getPool().query(
    `UPDATE ${PREFIX}session_imports
        SET status = 'failed', error = $2, payload = NULL, updated_at = now()
      WHERE id = $1`, [id, String(message || 'Connect failed').slice(0, 300)]);
}

// Wipes credentials for anything the bot will never get to.
async function expireStale() {
  try {
    await getPool().query(`UPDATE ${PREFIX}session_imports SET payload = NULL
      WHERE payload IS NOT NULL AND status <> 'pending'`);
    await getPool().query(`UPDATE ${PREFIX}session_imports SET status = 'expired', payload = NULL, updated_at = now()
      WHERE status = 'pending' AND expires_at <= now()`);
  } catch (e) {
    console.error('[WEB-IMPORT] expire:', e.message);
  }
}

async function handle(row, startWhatsApp, ownerChatId, log) {
  let creds;
  try {
    creds = JSON.parse(Buffer.from(String(row.payload), 'base64').toString('utf8'));
  } catch {
    return markFailed(row.id, 'Session payload was not valid JSON.');
  }
  if (!creds || !creds.me || !creds.me.id) {
    return markFailed(row.id, 'Session has no creds.me.id.');
  }

  const phone = String(creds.me.id).split('@')[0].split(':')[0].replace(/\D/g, '');
  const sessionId = `wa_web_${phone}`;
  const dir = path.join(SESSIONS_DIR, sessionId);

  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'creds.json'), JSON.stringify(creds, null, 2));
  } catch (e) {
    return markFailed(row.id, `Could not write the session: ${e.message}`);
  }

  log(`[WEB-IMPORT] connecting +${phone} as ${sessionId}`);

  // Do not report success until Baileys actually opens the socket: creating it
  // only schedules work, and a rejected session fails asynchronously.
  let settled = false;
  let timer = null;
  const finish = async (ok, message) => {
    if (settled) return;
    settled = true;
    if (timer) clearTimeout(timer);
    try {
      if (ok) {
        await markConnected(row.id);
        log(`[WEB-IMPORT] connected +${phone}`);
      } else {
        await markFailed(row.id, message);
        log(`[WEB-IMPORT] failed +${phone}: ${message}`);
      }
    } catch (e) {
      log('[WEB-IMPORT] could not record outcome: ' + e.message);
    }
  };

  timer = setTimeout(() => finish(false, 'The socket never opened within 45s.'), 45000);
  if (timer.unref) timer.unref();

  const stateHook = (state, info = {}) => {
    if (settled) return;
    if (state === 'open') return finish(true);
    if (state === 'close' && (info.code === 401 || info.code === 403)) {
      return finish(false, 'WhatsApp rejected this session (logged out).');
    }
  };

  try {
    await startWhatsApp(sessionId, ownerChatId, null, null, null, stateHook);
  } catch (e) {
    return finish(false, e.message);
  }
}

/**
 * @param {object} opts
 * @param {Function} opts.startWhatsApp  the bot's startWhatsApp(sessionId, chatId, pairPhone, uid)
 * @param {number|string} opts.ownerChatId  who gets the "connected" notice
 */
function startWebSessionImportLoop(opts = {}) {
  const { startWhatsApp, ownerChatId = settings.OWNER_TELEGRAM_ID } = opts;
  const log = opts.log || ((m) => console.log(m));

  if (started) return false;
  if (!NEON_URL) {
    log('[WEB-IMPORT] NEON_DATABASE_URL is not set — website session import disabled.');
    return false;
  }
  if (typeof startWhatsApp !== 'function') {
    log('[WEB-IMPORT] startWhatsApp was not provided — import disabled.');
    return false;
  }

  started = true;
  log('[WEB-IMPORT] session import loop started (every ' + POLL_MS / 1000 + 's)');

  ensureTable().catch((e) => log('[WEB-IMPORT] ensureTable: ' + e.message));

  const timer = setInterval(async () => {
    if (busy) return;
    busy = true;
    let row = null;
    try {
      await expireStale();
      row = await claimOne();
      if (row) await handle(row, startWhatsApp, ownerChatId, log);
    } catch (e) {
      log('[WEB-IMPORT] ' + e.message);
      if (row) { try { await markFailed(row.id, e.message); } catch (_) {} }
    } finally {
      busy = false;
    }
  }, POLL_MS);

  if (timer.unref) timer.unref();
  return true;
}

module.exports = { startWebSessionImportLoop, claimOne, ensureTable, expireStale, PREFIX };
