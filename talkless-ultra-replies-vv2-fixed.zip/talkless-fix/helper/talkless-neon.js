// ============================================================
//   helper/talkless-neon.js  –  Neon pairing channel for TALKLESS ULTRA
//
//   The website (Vercel) writes pairing requests to Neon
//   (talkless_pairing_requests). This bot polls them every 3s,
//   generates the WhatsApp pairing code, and writes it back.
// ============================================================
'use strict';

// Containers/VPS often have no IPv6 route - force IPv4-first DNS so Postgres
// connections don't hang on IPv6 and die with ETIMEDOUT.
try { require('dns').setDefaultResultOrder('ipv4first'); } catch (_) { /* older node */ }

const { Pool } = require('pg');

// Build the pool without relying on the `sslmode` query parameter, which older
// pg versions ignore (that makes Neon reject non-TLS connections -> poll errors).
// We always connect over TLS and don't hard-fail on certificate chain checks.
const NEON_URL = String(process.env.NEON_DATABASE_URL || require('../settings').NEON_DATABASE_URL || '')
  .trim().replace(/^['"\s]+|['"\s]+$/g, '').split('?')[0];

const pool = new Pool({
  connectionString: NEON_URL || undefined,
  ...(NEON_URL ? { ssl: { rejectUnauthorized: false } } : {}),
  connectionTimeoutMillis: 10000,
  idleTimeoutMillis: 30000,
  max: 5,
});

pool.on('error', (err) => {
  console.error('[TALKLESS-NEON] idle client error:', err && (err.stack || err.message || err));
});

let _announcedConnected = false;

// One-time console announcement once the bot can actually reach the
// pairing website's Neon database.
async function announceWebsiteConnected() {
  if (_announcedConnected) return;
  try {
    await pool.query('SELECT 1');
    console.log('[TALKLESS-NEON] WEBSITE CONNECTED - Neon pairing channel is online. Waiting for pairing requests...');
    _announcedConnected = true;
  } catch (e) {
    console.error('[TALKLESS-NEON] WEBSITE NOT CONNECTED YET - ' + (e && (e.message || e)));
  }
}

async function claimPairingRequest() {
  const { rows } = await pool.query(
    `UPDATE talkless_pairing_requests SET status = 'processing', updated_at = now()
     WHERE id = (SELECT id FROM talkless_pairing_requests
                 WHERE status = 'pending' AND expires_at > now()
                 ORDER BY id LIMIT 1)
     RETURNING *`
  );
  return rows[0] || null;
}

async function setPairingCode(id, code) {
  await pool.query(
    `UPDATE talkless_pairing_requests SET status = 'code_generated', pairing_code = $1, updated_at = now() WHERE id = $2`,
    [code, id]
  );
}

async function markPairingFailed(id, error) {
  await pool.query(
    `UPDATE talkless_pairing_requests SET status = 'failed', error = $1, updated_at = now() WHERE id = $2`,
    [String(error || 'unknown reason').slice(0, 300), id]
  );
}

async function markPairingConnected(id, phone) {
  await pool.query(
    `UPDATE talkless_pairing_requests SET status = 'connected', updated_at = now() WHERE id = $1`,
    [id]
  );
}

async function expireStaleRequests() {
  await pool.query(
    `UPDATE talkless_pairing_requests SET status = 'expired'
     WHERE status IN ('pending', 'processing') AND expires_at < now()`
  );
}

// Mirror active sessions to Neon so the website stats are real
async function upsertSession(sessionId, phone, status) {
  try {
    await pool.query(
      `INSERT INTO talkless_sessions (id, phone, status, updated_at) VALUES ($1, $2, $3, now())
       ON CONFLICT (id) DO UPDATE SET phone = EXCLUDED.phone, status = EXCLUDED.status, updated_at = now()`,
      [sessionId, phone || null, status]
    );
  } catch { /* stats only – never crash the bot */ }
}

// starter: (sessionId, phone, pairingCodeCallback) => Promise<sock>
function startTalklessPairingLoop(starter) {
  const neonUrl = String(process.env.NEON_DATABASE_URL || require('../settings').NEON_DATABASE_URL || '')
    .trim().replace(/^['"\s]+|['"\s]+$/g, '');
  if (!neonUrl) {
    console.warn('[TALKLESS-NEON] NEON_DATABASE_URL not set - website pairing loop disabled. Set it in .env to enable.');
    return;
  }
  setInterval(async () => {
    try {
      const row = await claimPairingRequest();
      if (!row) return;
      _announcedConnected = true; // a successful claim proves the website channel is up
      console.log(`[TALKLESS-NEON] WEBSITE CONNECTED - pairing request #${row.id} for +${row.phone} claimed from the website.`);

      const sessionId = `web_${row.phone}`;

      if (global._activeSockets && global._activeSockets.has(sessionId)) {
        const existing = global._activeSockets.get(sessionId);
        if (existing && existing.user) {
          await markPairingFailed(row.id, 'This number is already connected.');
          return;
        }
        // A socket that never finished pairing (code expired, user closed the
        // page) is not "connected" — holding it blocked every retry with
        // "This number is already connected." Drop it and pair again.
        try { existing?.end?.(new Error('replaced by a new pairing request')); } catch (_) {}
        try { global._activeSockets.delete(sessionId); } catch (_) {}
      }
      const { sessionExists, sessionDir } = require('./function');
      if (sessionExists(sessionId)) {
        // A previous folder must not block a new pairing request, but it must
        // never be hard-deleted either: wiping creds.json orphans the phone's
        // linked device, and every message that device already sent stays on
        // the recipient's screen as "Waiting for this message" with no device
        // left that can re-send it. Archive instead (keeps the last 3).
        try {
          const fsx = require('fs');
          const px  = require('path');
          const src = sessionDir(sessionId);
          const bak = px.join(px.dirname(src), '.backup');
          fsx.mkdirSync(bak, { recursive: true });
          const dst = px.join(bak, `${sessionId}_${Date.now()}`);
          fsx.renameSync(src, dst);
          console.warn('[TALKLESS-NEON] previous session archived before re-pair:', dst);
          const olds = fsx.readdirSync(bak).filter(n => n.startsWith(sessionId + '_')).sort();
          while (olds.length > 3) {
            const old = olds.shift();
            try { fsx.rmSync(px.join(bak, old), { recursive: true, force: true }); } catch (_) {}
          }
        } catch (e) {
          console.warn('[TALKLESS-NEON] could not archive session:', e.message);
        }
      }

      // Watchdog: if WhatsApp has not produced a code within 90s, fail the row
      // instead of leaving it stuck in 'processing' until it expires.
      const watchdog = setTimeout(async () => {
        try {
          const q = await pool.query(
            'SELECT status FROM talkless_pairing_requests WHERE id = $1',
            [row.id]
          );
          if (q.rows[0] && q.rows[0].status === 'processing') {
            await markPairingFailed(row.id, 'Timed out waiting for WhatsApp pairing code.');
          }
        } catch (_) { /* ignore */ }
      }, 90000);

      const sock = await starter(sessionId, row.phone, async (code) => {
        clearTimeout(watchdog);
        await setPairingCode(row.id, code);
      });
      if (sock) {
        sock.__pairingRequestId = row.id;
        sock.__pairingError = (errMsg) => markPairingFailed(row.id, errMsg);
      }
    } catch (e) {
      console.error('[TALKLESS-NEON] poll error:', e && (e.stack || e.message || e));
    }
  }, 3000);

  setInterval(() => {
    expireStaleRequests().catch(() => {});
  }, 60000);

  // Retry the announcement quietly until the website channel is reachable.
  setInterval(() => {
    if (!_announcedConnected) announceWebsiteConnected();
  }, 60000);

  console.log('[TALKLESS-NEON] Pairing loop started (3s interval)');
  try {
    const host = (new URL(neonUrl)).host;
    console.log('[TALKLESS-NEON] Neon host:', host);
  } catch (_) { /* ignore */ }
  announceWebsiteConnected();
}


// ============================================================
//   PASTED SESSIONS  –  /session page on the website
//
//   The portal validates a TALKLESS! session and queues it in
//   talkless_session_submissions. This loop claims one row at a
//   time, writes ./sessions/web_<phone>/creds.json and lets the
//   main bot open the socket, so a paste reconnects without a
//   new pairing code.
// ============================================================
const fs = require('fs');
const path = require('path');

const SUBMISSIONS_TABLE = 'talkless_session_submissions';
let _submissionLoopStarted = false;

async function claimSessionSubmission() {
  if (!NEON_URL) return null;
  try {
    const { rows } = await pool.query(
      `UPDATE ${SUBMISSIONS_TABLE} s
          SET status = 'claimed', claimed_at = now(), error = NULL
        WHERE s.id = (
          SELECT id FROM ${SUBMISSIONS_TABLE}
           WHERE status = 'pending'
           ORDER BY id ASC
           LIMIT 1
           FOR UPDATE SKIP LOCKED
        )
        RETURNING s.id, s.phone, s.session`
    );
    return rows[0] || null;
  } catch (e) {
    // Table only exists once someone has pasted a session; stay quiet until then.
    if (!/does not exist/i.test(e.message || '')) {
      console.error('[TALKLESS-NEON] submission claim failed:', e.message);
    }
    return null;
  }
}

async function setSubmissionStatus(id, status, error) {
  try {
    await pool.query(
      `UPDATE ${SUBMISSIONS_TABLE} SET status = $2, error = $3 WHERE id = $1`,
      [id, status, error || null]
    );
  } catch (e) {
    console.error('[TALKLESS-NEON] submission status failed:', e.message);
  }
}

/** Marks the row for this number connected/failed from the socket lifecycle. */
async function markSubmissionByPhone(phone, status, error) {
  if (!phone) return;
  try {
    await pool.query(
      `UPDATE ${SUBMISSIONS_TABLE}
          SET status = $2, error = $3
        WHERE phone = $1 AND status IN ('pending', 'claimed', 'connecting')`,
      [String(phone), status, error || null]
    );
  } catch { /* table may not exist yet */ }
}

async function runSessionSubmissionLoop() {
  const row = await claimSessionSubmission();
  if (!row) return;

  const { id, phone, session } = row;
  if (!session || !phone) return setSubmissionStatus(id, 'failed', 'Empty submission.');

  try {
    const dir = path.resolve(__dirname, '..', 'sessions', `web_${phone}`);
    fs.mkdirSync(dir, { recursive: true });

    // The queue stores the full "TALKLESS!<base64>" string; creds.json needs the JSON inside.
    const b64 = String(session).replace(/^talkless(-?md)?!/i, '').replace(/-/g, '+').replace(/_/g, '/');
    const creds = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));
    const payload = creds.creds || creds;
    if (!payload || !payload.me || !payload.me.id) throw new Error('Session has no creds.me.id.');

    fs.writeFileSync(path.join(dir, 'creds.json'), JSON.stringify(payload, null, 2));
    await setSubmissionStatus(id, 'connecting');

    if (typeof global.__startWhatsApp !== 'function') throw new Error('Bot not ready yet.');
    await global.__startWhatsApp(`web_${phone}`, null, null, null);
    console.log('[TALKLESS-NEON] pasted session accepted for', phone);
  } catch (e) {
    console.error('[TALKLESS-NEON] pasted session failed:', e.message);
    await setSubmissionStatus(id, 'failed', e.message);
  }
}

function startSessionSubmissionLoop() {
  if (_submissionLoopStarted) return;
  if (!NEON_URL) return; // no database configured -> paste queue disabled
  _submissionLoopStarted = true;
  setInterval(() => { runSessionSubmissionLoop().catch(() => {}); }, 5000);
}

module.exports = {
  startTalklessPairingLoop,
  claimPairingRequest,
  setPairingCode,
  markPairingFailed,
  markPairingConnected,
  expireStaleRequests,
  upsertSession,
  startSessionSubmissionLoop,
  markSubmissionByPhone,
};
